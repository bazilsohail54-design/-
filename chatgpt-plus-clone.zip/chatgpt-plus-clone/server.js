import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import multer from "multer";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "chats.json");
const APP_PASSWORD = process.env.APP_PASSWORD || "";
const SESSION_SECRET = process.env.SESSION_SECRET || "";
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ chats: [] }, null, 2));

app.use(express.json({ limit: "25mb" }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 5 }
});

function readDB() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return { chats: [] }; }
}
function writeDB(db) {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function tokenFor(exp) {
  const payload = Buffer.from(JSON.stringify({ exp })).toString("base64url");
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
function validToken(token) {
  if (!token || !SESSION_SECRET) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest();
  let actual;
  try { actual = Buffer.from(sig, "base64url"); } catch { return false; }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return false;
  try { return JSON.parse(Buffer.from(payload, "base64url").toString()).exp > Date.now(); }
  catch { return false; }
}
function requireAuth(req, res, next) {
  if (validToken(req.cookies?.session || req.headers.cookie?.split(";").map(x=>x.trim()).find(x=>x.startsWith("session="))?.slice(8))) return next();
  return res.status(401).json({ error: "Please unlock your private workspace." });
}
// Minimal cookie parser
app.use((req, _res, next) => {
  req.cookies = {};
  for (const part of (req.headers.cookie || "").split(";")) {
    const i = part.indexOf("=");
    if (i > -1) req.cookies[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  next();
});

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(openai && APP_PASSWORD && SESSION_SECRET), appName: "ChatGPT Plus Clone" });
});
app.post("/api/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), (req, res) => {
  if (!APP_PASSWORD || !SESSION_SECRET) return res.status(503).json({ error: "Set APP_PASSWORD and SESSION_SECRET in .env first." });
  const submitted = String(req.body?.password || "");
  const a = Buffer.from(submitted), b = Buffer.from(APP_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: "Incorrect password." });
  const cookie = tokenFor(Date.now() + 1000 * 60 * 60 * 24 * 14);
  res.setHeader("Set-Cookie", `session=${cookie}; HttpOnly; SameSite=Lax; Path=/; Max-Age=1209600${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  res.json({ ok: true });
});
app.post("/api/logout", (_req, res) => {
  res.setHeader("Set-Cookie", "session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0");
  res.json({ ok: true });
});

app.get("/api/chats", requireAuth, (_req, res) => {
  const { chats } = readDB();
  res.json(chats.sort((a,b) => b.updatedAt - a.updatedAt).map(({ id, title, updatedAt }) => ({ id, title, updatedAt })));
});
app.get("/api/chats/:id", requireAuth, (req, res) => {
  const chat = readDB().chats.find(c => c.id === req.params.id);
  if (!chat) return res.status(404).json({ error: "Chat not found." });
  res.json(chat);
});
app.delete("/api/chats/:id", requireAuth, (req, res) => {
  const db = readDB(); db.chats = db.chats.filter(c => c.id !== req.params.id); writeDB(db);
  res.json({ ok: true });
});
app.patch("/api/chats/:id", requireAuth, (req, res) => {
  const db = readDB(); const chat = db.chats.find(c => c.id === req.params.id);
  if (!chat) return res.status(404).json({ error: "Chat not found." });
  chat.title = String(req.body.title || chat.title).slice(0, 100); chat.updatedAt = Date.now(); writeDB(db);
  res.json(chat);
});

const chatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
app.post("/api/chat", requireAuth, chatLimiter, upload.array("files", 5), async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: "OpenAI is not configured. Add OPENAI_API_KEY to .env." });
    const message = String(req.body.message || "").trim();
    if (!message && !(req.files || []).length) return res.status(400).json({ error: "Write a message or attach a file." });
    const db = readDB();
    let chat = db.chats.find(c => c.id === req.body.chatId);
    if (!chat) {
      chat = { id: crypto.randomUUID(), title: (message || "New conversation").slice(0, 48), messages: [], updatedAt: Date.now() };
      db.chats.push(chat);
    }
    const model = String(req.body.model || process.env.DEFAULT_MODEL || "gpt-6-astra");
    const useSearch = req.body.webSearch === "true";
    const userContent = [];
    if (message) userContent.push({ type: "input_text", text: message });
    for (const file of (req.files || [])) {
      const mime = file.mimetype || "application/octet-stream";
      const data = `data:${mime};base64,${file.buffer.toString("base64")}`;
      if (mime.startsWith("image/")) userContent.push({ type: "input_image", image_url: data });
      else userContent.push({ type: "input_file", filename: file.originalname, file_data: data });
    }
    const history = chat.messages.slice(-20).map(m => ({ role: m.role, content: m.content }));
    const input = [...history, { role: "user", content: userContent.length ? userContent : message }];
    const response = await openai.responses.create({
      model,
      input,
      ...(useSearch ? { tools: [{ type: "web_search" }], include: ["web_search_call.action.sources"] } : {})
    });
    const answer = response.output_text || "I couldn't produce a text response.";
    chat.messages.push({ role: "user", content: message || "Please analyze the attached file(s).", files: (req.files || []).map(f => f.originalname), createdAt: Date.now() });
    chat.messages.push({ role: "assistant", content: answer, createdAt: Date.now(), responseId: response.id });
    chat.updatedAt = Date.now();
    writeDB(db);
    res.json({ chatId: chat.id, answer, title: chat.title, responseId: response.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.status === 401 ? "The API key was rejected. Check OPENAI_API_KEY." : (err?.message || "The AI request failed.") });
  }
});

app.post("/api/image", requireAuth, async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: "OpenAI is not configured. Add OPENAI_API_KEY to .env." });
    const prompt = String(req.body.prompt || "").trim();
    if (!prompt) return res.status(400).json({ error: "Enter an image prompt." });
    const result = await openai.images.generate({
      model: process.env.IMAGE_MODEL || "gpt-image-2.5-sunburst",
      prompt, size: "1024x1024", quality: "medium", n: 1
    });
    res.json({ image: `data:image/png;base64,${result.data[0].b64_json}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || "Image generation failed." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`ChatGPT Plus Clone running at http://localhost:${PORT}`));
