# ChatGPT Plus Clone — personal web app

A private, single-user ChatGPT-style web application. It is a starter product, not an official OpenAI/ChatGPT product.

## Features included
- Private password-protected workspace (one owner)
- Chat history stored on the server in `data/chats.json`
- Model selector (model IDs can be changed to models enabled for your API key)
- OpenAI Responses API chat backend
- Optional web search toggle with the Responses API `web_search` tool
- File and image uploads (PDF, Office files, spreadsheets, text, common images)
- Image generation through the OpenAI Images API
- Browser speech recognition for voice input
- Responsive desktop/mobile interface
- Delete conversations and start new chats

## Requirements
- Node.js 20+
- An OpenAI API key with API billing enabled
- Models/tools enabled for your API account

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add your API key, a strong private password, and a long random session secret.
6. Run `npm start`.
7. Open `http://localhost:3000`.

Example session secret generation:
- macOS/Linux: `openssl rand -hex 32`
- PowerShell: `[Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`

## Model configuration
The UI offers sample model IDs. Availability depends on your OpenAI API account. Change the `<option>` values in `public/index.html` to model IDs available to your key, and set `DEFAULT_MODEL` in `.env` to your preferred default.

## Deployment
Deploy to a Node.js host that supports a persistent disk. Set `OPENAI_API_KEY`, `APP_PASSWORD`, `SESSION_SECRET`, and optionally `DEFAULT_MODEL`, `IMAGE_MODEL`, and `NODE_ENV=production` as environment variables. Keep the `data/` directory on persistent storage because it contains your chat history. Use HTTPS in production.

## Important limitations / next engineering steps
- This is a personal MVP, not a 1:1 reproduction of ChatGPT Plus. It does not grant access to a ChatGPT Plus subscription or proprietary ChatGPT account features.
- API usage is billed separately from ChatGPT subscriptions. Model availability, rate limits, and image-generation access depend on your API account.
- Voice input uses the browser's speech recognition. Voice output can be added with a speech API integration; this build does not include real-time, low-latency voice conversations.
- Chat persistence uses a local JSON file and is intended for one user / low concurrency. For production-grade reliability, migrate to SQLite or PostgreSQL, add backups, CSRF protection, stronger session management, and upload scanning.
- Uploaded files are sent to the configured OpenAI API. Do not upload sensitive files unless you understand your API data controls.
- Web search is enabled only when you switch it on in the composer. Citations are returned in the model's answer where available.
- The app currently sends recent chat messages as context. For long chats, add compaction or Responses API conversation-state management.
