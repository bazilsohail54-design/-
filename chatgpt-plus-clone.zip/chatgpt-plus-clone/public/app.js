const $ = (id) => document.getElementById(id);
let currentChat = null, attachedFiles = [], webSearch = false, busy = false;
const messages = $("messages"), promptBox = $("prompt");

async function api(url, options={}) {
  const res = await fetch(url, options);
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}
function showApp() { $("login").classList.add("hidden"); $("app").classList.remove("hidden"); loadChats(); }
async function boot() {
  try {
    const status = await api("/api/status");
    if (!status.configured) { $("login").classList.remove("hidden"); $("loginError").textContent="Server setup incomplete. Configure .env before signing in."; return; }
    try { await api("/api/chats"); showApp(); }
    catch { $("login").classList.remove("hidden"); }
  } catch { $("login").classList.remove("hidden"); $("loginError").textContent="Could not reach the app server."; }
}
$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); $("loginError").textContent="";
  try { await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("password").value})}); $("password").value=""; showApp(); }
  catch(err){ $("loginError").textContent=err.message; }
});
$("logout").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload();};
function newChat() { currentChat=null; messages.innerHTML=""; $("welcome").classList.remove("hidden"); promptBox.focus(); renderActive(); }
$("newChat").onclick=newChat;
function renderActive(){document.querySelectorAll(".chat-item").forEach(el=>el.classList.toggle("active",el.dataset.id===currentChat));}
async function loadChats(){
  try { const chats=await api("/api/chats"); $("chatList").innerHTML="";
    chats.forEach(c=>{const el=document.createElement("div");el.className="chat-item";el.dataset.id=c.id;
      const label=document.createElement("span");label.textContent=c.title||"New chat";
      const del=document.createElement("button");del.className="delete-chat";del.textContent="×";del.title="Delete chat";
      del.onclick=async e=>{e.stopPropagation();if(confirm("Delete this conversation?")){await api(`/api/chats/${c.id}`,{method:"DELETE"});if(currentChat===c.id)newChat();loadChats();}};
      el.append(label,del);el.onclick=()=>openChat(c.id);$("chatList").append(el);
    });renderActive();
  } catch(e){console.error(e);}
}
async function openChat(id){
  const chat=await api(`/api/chats/${id}`);currentChat=id;messages.innerHTML="";$("welcome").classList.add("hidden");
  chat.messages.forEach(m=>addMessage(m.role,m.content,m.files));renderActive();$("conversation").scrollTop=$("conversation").scrollHeight;
}
function addMessage(role,content,files=[]){
  const row=document.createElement("div");row.className=`message ${role}`;
  const av=document.createElement("div");av.className="avatar-msg";av.textContent=role==="user"?"Y":"✳";
  const body=document.createElement("div");body.className="message-body";
  const p=document.createElement("p");p.textContent=content||"";
  body.append(p);
  if(files?.length){const meta=document.createElement("div");meta.className="message-meta";meta.textContent="Attachments: "+files.join(", ");body.append(meta);}
  row.append(av,body);messages.append(row);return body;
}
function setBusy(v){busy=v;$("send").disabled=v;$("send").textContent=v?"…":"↑";}
$("composer").addEventListener("submit",async e=>{
  e.preventDefault();if(busy)return;
  const text=promptBox.value.trim();if(!text&&!attachedFiles.length)return;
  $("welcome").classList.add("hidden");addMessage("user",text||"Please analyze the attached file(s).",attachedFiles.map(f=>f.name));
  const form=new FormData();form.append("message",text);if(currentChat)form.append("chatId",currentChat);
  form.append("model",$("model").value);form.append("webSearch",String(webSearch));attachedFiles.forEach(f=>form.append("files",f));
  promptBox.value="";promptBox.style.height="auto";attachedFiles=[];renderAttachments();setBusy(true);
  const waiting=addMessage("assistant","Thinking…");waiting.classList.add("typing");
  try{
    const data=await api("/api/chat",{method:"POST",body:form});currentChat=data.chatId;waiting.textContent=data.answer;waiting.classList.remove("typing");await loadChats();
  }catch(err){waiting.textContent="Error: "+err.message;waiting.classList.remove("typing");}
  finally{setBusy(false);$("conversation").scrollTop=$("conversation").scrollHeight;promptBox.focus();}
});
promptBox.addEventListener("input",()=>{promptBox.style.height="auto";promptBox.style.height=Math.min(promptBox.scrollHeight,180)+"px";});
promptBox.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("composer").requestSubmit();}});
$("attach").onclick=()=>$("fileInput").click();
$("fileInput").onchange=e=>{attachedFiles.push(...e.target.files);renderAttachments();e.target.value="";};
function renderAttachments(){$("attachmentPreview").innerHTML="";attachedFiles.forEach((f,i)=>{const chip=document.createElement("span");chip.className="file-chip";chip.textContent=f.name+" ×";chip.onclick=()=>{attachedFiles.splice(i,1);renderAttachments();};$("attachmentPreview").append(chip);});}
$("searchToggle").onclick=()=>{webSearch=!webSearch;$("searchToggle").classList.toggle("on",webSearch);$("searchLabel").textContent=webSearch?"Web search on":"Web search off";};
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{promptBox.value=b.dataset.prompt;promptBox.focus();});
$("openSidebar").onclick=()=>$("sidebar").classList.add("open");$("closeSidebar").onclick=()=>$("sidebar").classList.remove("open");
$("imageFab").onclick=()=>{$("imageModal").classList.remove("hidden");$("imagePrompt").focus();};
$("closeImage").onclick=()=>$("imageModal").classList.add("hidden");
$("generateImage").onclick=async()=>{
  const prompt=$("imagePrompt").value.trim();if(!prompt)return;
  const btn=$("generateImage");btn.disabled=true;btn.textContent="Generating…";$("imageResult").innerHTML="";
  try{const data=await api("/api/image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
    const img=document.createElement("img");img.src=data.image;img.alt=prompt;$("imageResult").append(img);
  }catch(e){$("imageResult").textContent=e.message;}
  finally{btn.disabled=false;btn.textContent="Generate image";}
};
let recognition;
$("voice").onclick=()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){alert("Voice input is not supported in this browser. Try a current version of Chrome.");return;}
  if(recognition){recognition.stop();recognition=null;return;}
  recognition=new SR();recognition.lang=navigator.language||"en-US";recognition.interimResults=true;
  recognition.onresult=e=>{let t="";for(let i=e.resultIndex;i<e.results.length;i++)t+=e.results[i][0].transcript;promptBox.value=t;};
  recognition.onend=()=>{recognition=null;};recognition.onerror=()=>{recognition=null;};recognition.start();
};
boot();
